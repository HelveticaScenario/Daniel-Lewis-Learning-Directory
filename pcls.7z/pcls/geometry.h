#ifndef lines_akjerb
#define lines_akjerb

typedef struct point{
  float x, y;
}point;

typedef struct line{
  double x1, x2, y1, y2;
}line;

#endif