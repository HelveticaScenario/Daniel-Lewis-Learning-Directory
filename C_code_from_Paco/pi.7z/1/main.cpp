#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <time.h>

int main()
{
    srand(time(0));
    unsigned int skips = 0;
    unsigned int n = 0;
    double total = 0;
    double average = 0;
    while(1)
    {
        std::cout << "How many rands should I generate? ";
        std::cin >> skips;
        for(unsigned int i = 0; i < skips; i++)
        {
            total += rand();
        }
        n += skips;
        average = total / n;
        std::cout << "RAND_MAX is thought to be " << average * 2 << std::endl;
    }
    return 0;
}
