#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <time.h>

int main()
{
    srand(time(0));
    unsigned int n;
    unsigned int skips = 0;
    unsigned int high = 0;
    while(1)
    {
        std::cout << "How many rands should I generate? ";
        std::cin >> skips;
        high = 0;
        for(unsigned int i = 0; i < skips; i++)
        {
            n = rand();
            if(n > high)
            {
                high = n;
            }
        }
        std::cout << "RAND_MAX is thought to be " << high << std::endl;
    }
    return 0;
}
