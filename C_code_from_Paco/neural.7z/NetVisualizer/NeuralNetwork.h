#ifndef Feedforward_NN_Paco_Included
#define Feedforward_NN_Paco_Included

//extern ffftanh(double x);

class NeuralNetwork
{
    public:

    int layers;
    int* layerSize;
    double** state;
    double*** connection;

    void Init(int length, int* sizes);
    void Reset();
    void Run(double* input);
    void RunFast(double* input);
};

double ftanh(double x);

double fftanh(double x);

#endif // Feedforward_NN_Paco_Included
