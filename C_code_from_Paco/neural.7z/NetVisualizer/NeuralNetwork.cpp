#include <cmath>
#include "NeuralNetwork.h"

void NeuralNetwork::Init(int length, int* sizes)
{
    layers = length;
    layerSize = new int[layers];
    state = new double*[layers];
    connection = new double**[layers-1];
    for(int i = 0; i < layers; i++)
    {
        layerSize[i] = sizes[i];
        state[i] = new double[layerSize[i]];
        for(int ii = 0; ii < layerSize[i]; ii++)
        {
            state[i][ii]  = 0;
        }
    }
    for(int i = 0; i < layers-1; i++)
    {
        connection[i] = new double*[layerSize[i]];
        for(int ii = 0; ii < layerSize[i]; ii++)
        {
            connection[i][ii] = new double[layerSize[i+1]];
            for(int iii = 0; iii < layerSize[i+1]; iii++)
            {
                connection[i][ii][iii] = 0;
            }
        }
    }
    layerSize[layers-1] = sizes[layers-1];
    state[layers-1] = new double[layerSize[layers-1]];
}

void NeuralNetwork::Reset()
{
    layers = 0;
    delete[] layerSize;
    delete[] state;
    delete[] connection;
}

void NeuralNetwork::Run(double* input)
{
    double sum;
    for(int i = 0; i < layerSize[0]; i++)
    {
        state[0][i] = input[i];
    }
    for(int i = 1; i < layers; i++)
    {
        for(int ii = 0; ii < layerSize[i]; ii++)
        {
            sum = 0;
            for(int iii = 0; iii < layerSize[i-1]; iii++)
            {
                sum += state[i-1][iii] * connection[i-1][iii][ii];
            }
            state[i][ii] = tanh(sum);
        }
    }
}

void NeuralNetwork::RunFast(double* input)
{
    double sum;
    for(int i = 0; i < layerSize[0]; i++)
    {
        state[0][i] = input[i];
    }
    for(int i = 1; i < layers; i++)
    {
        for(int ii = 0; ii < layerSize[i]; ii++)
        {
            sum = 0;
            for(int iii = 0; iii < layerSize[i-1]; iii++)
            {
                sum += state[i-1][iii] * connection[i-1][iii][ii];
            }
            state[i][ii] = fftanh(sum);
        }
    }
}

double ftanh(double x)
{
    if(x > 1.92033)
    {
        return 0.96016;
    }
    if(x < -1.92033)
    {
        return -0.96016;
    }
    if(x > 0)
    {
        return 0.96016 - 0.26037 * ((x - 1.92033)*(x - 1.92033));
    }
    if(x < 0)
    {
        return 0.26037 * ((x + 1.92033)*(x + 1.92033)) - 0.96016;
    }
    return 0;
}

double   fftanh (double x)
{
   const double   xa = fabs (x);
   const double   x2 = x * x;
   const double   x4 = x2 * x2;
   const double   poly = xa + x2 + x4;
   const double   resa = poly / (1 + poly);
   const double   result = (x < 0) ? -resa : resa;

   return (result);
}
