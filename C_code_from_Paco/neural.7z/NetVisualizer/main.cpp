#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include "NeuralNetwork.h"

//Callback function
LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM);

//Boring functions
bool RegisterWindowClass(HINSTANCE hInst, const char lpCN[]); //Sets up a window class.
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*); //Enables OpenGL
void DisableOpenGL(HWND, HDC, HGLRC); //Disables OpenGL

//Functions
void Config (); //Displays config
void Create (); //User creates a neural network
void Load(); //User loads a neural network
void LoadConfig(); //Loads the config file. If there isn't one, it is created.
void Save(); //Saves the current network
void SavePrompt (); //Saves the current network through prompt
void SaveConfig (); //Saves config to disk
void Use (); //Prompts to use the network
void Randomize (); //Randomizes the neural network
void Picture (); //Draws a picture with the neural network
//Drawing Functions
void DrawConnections();
void DrawNodes();
void DrawLayerStates(int layer);

//Globals
bool quit = true;
bool open = false;
bool flip = false;

//Config variable defaults (if config.txt does not exist)
std::string name; //The name of the current neural network
bool tellTime = 1; //Whether to tell time taken
bool fast = 1;
int windowWidth = 400;
int windowHeight = 400;

NeuralNetwork nn; //Described in NeuralNetwork.h

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    //Declare some Windows variables...
    HWND hwnd;
    HDC hDC;
    HGLRC hRC;
    MSG msg;
    const char lpCN[] = "Neural Network"; //lpClassName
    const char lpWN[] = "Neural Network Visualizer"; //lpWindowName

    //Get the window set up (don't display it yet)
    if (!RegisterWindowClass(hInstance, lpCN))
    {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    //Holds user's answer
    char answer;

    LoadConfig();

    hwnd = CreateWindowEx(0, lpCN, lpWN, WS_BORDER, CW_USEDEFAULT, CW_USEDEFAULT, windowWidth, windowHeight, NULL, NULL, hInstance, NULL);
    EnableOpenGL(hwnd, &hDC, &hRC);
    ShowWindow(hwnd, nCmdShow);
    ShowWindow(hwnd, SW_HIDE); //Show then hide the window.

    if(name == "")
    {

        std::cout << "Hello. Would you like to (C)reate a network or (L)oad a network?" << std::endl;
        std::cin >> answer;
        if((answer == 'c') or (answer == 'C'))
        {
            std::cout << "What would you like to name the network?" << std::endl;
            std::cin >> name;
            Create();
            quit = false;
        }
        if((answer == 'l') or (answer == 'L'))
        {
            std::cout << "What is the name of the network?" << std::endl;
            std::cin >> name;
            Load();
            quit = false;
        }
    }
    else
    {
        Load();
        quit = false;
    }
    while(!quit)//Main Menu Loop
    {
        std::cout << "\nNetwork: " << name << std::endl << "Layers: " << nn.layers << std::endl << "Layer Sizes: ";
        for(int i = 0; i < nn.layers; i++)
        {
            std::cout << nn.layerSize[i] << " ";
        }
        std::cout << std::endl << "(U)se\n(R)andomize\n(P)icture\n\n(S)ave\n(L)oad\n(C)reate\n\n(Q)uit\n(X)Settings" << std::endl;
        std::cin >> answer;
        switch (answer)
        {
        case 'u':
        case 'U':
            Use();
            break;
        case 'r':
        case 'R':
            Randomize();
            break;
        case 'p':
        case 'P':
            ShowWindow(hwnd, SW_SHOW);
            open = true;
            Picture();
            SwapBuffers(hDC);
            while(open)
            {
                if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
                {
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
                if(flip)
                {
                    SwapBuffers(hDC);
                    flip = false;
                }
                Sleep(1);
            }
            ShowWindow(hwnd, SW_HIDE);
            break;

        case 's':
        case 'S':
            Save();
            break;
        case 'l':
        case 'L':
            std::cout << "What is the name of the network?" << std::endl;
            std::cin >> name;
            Load();
            break;
        case 'c':
        case 'C':
            std::cout << "What would you like to name the network?" << std::endl;
            std::cin >> name;
            Create();
            break;

        case 'x':
        case 'X':
            Config();
            break;
        default:
            quit = true;
            break;
        }
    }

    DisableOpenGL(hwnd, hDC, hRC);

    DestroyWindow(hwnd);

    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_CLOSE:
        open = false;
        break;

    case WM_DESTROY:
        open = false;
        return 0;

    case WM_KEYDOWN:
    {
        switch (wParam)
        {
        case VK_RETURN:
        case VK_ESCAPE:
            open = false;
            printf("wParam is %X\nlParam is %X\n", wParam, lParam);
            break;
        case VK_RIGHT: //P key
            printf("wParam is %X\nlParam is %X\n", wParam, lParam);
            Randomize();
            Picture();
            flip = true;
            break;
        case VK_DOWN: //F key
            printf("wParam is %X\nlParam is %X\n", wParam, lParam);
            flip = true;
            break;
        }
    }
    break;

    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }

    return 0;
}


void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC)
{
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;

    /* get the device context (DC) */
    *hDC = GetDC(hwnd);

    /* set the pixel format for the DC */
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);

    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC)
{
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}

void DrawConnections()
{
    int xSpace = windowWidth / (nn.layers + 1);
    int ySpace;
    int ySpace2;
    //float color;

    glPushMatrix();

    gluOrtho2D(0, windowWidth, 0, windowHeight);

    glBegin(GL_LINES);

    glColor3f(0.7f, 0.7f, 0.7f);

    for(int i = 0; i < nn.layers-1; i++)
    {
        ySpace = windowHeight / (nn.layerSize[i]+1);
        ySpace2 = windowHeight / (nn.layerSize[i+1]+1);
        for(int ii = 0; ii < nn.layerSize[i]; ii++)
        {
            for(int iii = 0; iii < nn.layerSize[i+1]; iii++)
            {
                //color = (float)nn.connection[i][ii][iii];
                //glColor3f(color, color, color);
                glVertex2f((i+1) * xSpace, (ii+1) * ySpace);
                glVertex2f((i+2) * xSpace, (iii+1) * ySpace2);
            }
        }
    }

    glEnd();

    glPopMatrix();
}

void DrawNodes()
{
    int xSpace = windowWidth / (nn.layers + 1);
    int ySpace;
    //float color;

    glPushMatrix();

    gluOrtho2D(0, windowWidth, 0, windowHeight);

    glBegin(GL_QUADS);

    glColor3f(1.f, 1.f, 1.f);

    std::cout << std::endl;

    for(int i = 0; i < nn.layers; i++)
    {
        ySpace = windowHeight / (nn.layerSize[i]+1);
        for(int ii = 0; ii < nn.layerSize[i]; ii++)
        {
            /*color = .2f;
            if(nn.state[i][ii] > 0)
            {
                color = 1.f;
            }
            glColor3f(color, color, color);
            *///Brightness based on state

            glVertex2f((i+1) * xSpace + 5, (ii+1) * ySpace + 5);
            glVertex2f((i+1) * xSpace + 5, (ii+1) * ySpace - 5);
            glVertex2f((i+1) * xSpace - 5, (ii+1) * ySpace - 5);
            glVertex2f((i+1) * xSpace - 5, (ii+1) * ySpace + 5);
        }
    }

    glEnd();

    glPopMatrix();
}

void DrawLayerStates(int layer)
{
    int xSpace = windowWidth / (nn.layers + 1);
    int ySpace = windowWidth / (nn.layerSize[layer] + 1);

    glPushMatrix();

    gluOrtho2D(0, windowWidth, 0, windowHeight);

    glBegin(GL_QUADS);

    glColor3f(1.f, 1.f, 1.f);

    for(int i = 0; i < nn.layerSize[layer]; i++)
    {
        if(nn.state[layer][i] > 0)
        {
            glVertex2f((layer+1) * xSpace + 5, (i+1) * ySpace + 5);
            glVertex2f((layer+1) * xSpace + 5, (i+1) * ySpace - 5);
            glVertex2f((layer+1) * xSpace - 5, (i+1) * ySpace - 5);
            glVertex2f((layer+1) * xSpace - 5, (i+1) * ySpace + 5);
        }
    }

    glEnd();

    glPopMatrix();
}

bool RegisterWindowClass(HINSTANCE hInst, const char lpCN[])
{
    WNDCLASSEX wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC;
    wcex.lpfnWndProc = WindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInst;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = lpCN;
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wcex))
    {
        return false;
    }
    return true;
}

void Config ()
{
    std::cout<< "Window width: " << windowWidth << std::endl << "Window height: " << windowHeight << std::endl;
}

void Create ()
{
    int answer;
    int* tempArray;
    nn.layerSize = new int[1];
    nn.layers = 0;
    int m = 0;
    int n = 0;
    double weight;
    srand(time(0));

    while(1)
    {
        nn.layers++;
        std::cout << "Please tell me the size of layer number " << nn.layers << "." << std::endl;
        std::cin >> answer;
        if(answer == 0)
        {
            nn.layers--;
            nn.Init(nn.layers, nn.layerSize);
            std::cout << "Enter 1 if you want random weights. Anything else leaves them at 0." << std::endl;
            std::cin >> answer;
            if(answer == 1)
            {
                m = 1;
            }
            for(int i = 0; i < nn.layers-1; i++)
            {
                for(int ii = 0; ii < nn.layerSize[i]; ii++)
                {
                    for(int iii = 0; iii < nn.layerSize[i+1]; iii++)
                    {
                        n = rand();
                        if(n > (32767 / 2))
                        {
                            n = 1;
                        }
                        else
                        {
                            n = -1;
                        }
                        weight = (rand() * m * n) / (double)32767;
                        nn.connection[i][ii][iii] = weight;
                    }
                }
            }
            return;
        }
        tempArray = new int[nn.layers];
        for(int i = 0; i < nn.layers; i++)
        {
            tempArray[i] = nn.layerSize[i];
        }
        delete[] nn.layerSize;
        nn.layerSize = new int[nn.layers];
        for(int i = 0; i < nn.layers; i++)
        {
            nn.layerSize[i] = tempArray[i];
        }
        delete[] tempArray;
        nn.layerSize[nn.layers-1] = answer;
    }
}

void Load ()
{
    std::ifstream file;
    std::string fileName = name;

    fileName.append(".txt");
    file.open(fileName.c_str(), std::ios::in);
    if(file.is_open())
    {
        file >> nn.layers;
        nn.layerSize = new int[nn.layers];
        for(int i = 0; i < nn.layers; i++)
        {
            file >> nn.layerSize[i];
        }
        nn.Init(nn.layers, nn.layerSize);
        for(int i = 0; i < nn.layers-1; i++)
        {
            for(int ii = 0; ii < nn.layerSize[i]; ii++)
            {
                for(int iii = 0; iii < nn.layerSize[i+1]; iii++)
                {
                    file >> nn.connection[i][ii][iii];
                }
            }
        }
        file.close();
    }
    else
    {
        std::cout << "I was unable to open the file." << std::endl;
    }
}

void LoadConfig ()
{
    std::fstream file;
    file.open("config.txt", std::ios::in);
    if(file.is_open())
    {
        file >> windowWidth;
        file >> windowHeight;
        file >> name;
        file.get();
        file.ignore(256,'\n');//Go to end of line
        file.close();
    }
    else
    {
        file.open("config.txt", std::ios::out);
        if(file.is_open())
        {
            std::cout << "Creating config.txt...." << std::endl;
            file << windowWidth << std::endl << windowHeight << std::endl << name << std::endl << tellTime << " - Notifies time taken to make pictures." << std::endl;
            file.close();
        }
        else
        {
            std::cout << "Something has gone terribly wrong. (LoadConfig)" << std::endl;
        }
    }
}

void Picture ()
{
    double* input;
    input = new double[3];
    input[2] = 1;
    int mills;
    mills = clock();

    glPushMatrix();

    gluOrtho2D(0, windowWidth, 0, windowHeight);

    glBegin(GL_POINTS);

    for(int i = 0; i < windowWidth; i++)
    {
        for(int ii = 0; ii < windowHeight; ii++)
        {
            input[0] = i / (double)windowWidth * 2 - 1;
            input[1] = ii / (double)windowHeight * 2 - 1;
            if(fast)
            {
                nn.RunFast(input);
            }
            else
            {
                nn.Run(input);
            }
            glColor3d((nn.state[nn.layers-1][0] + 1) / 2, (nn.state[nn.layers-1][1] + 1) / 2, (nn.state[nn.layers-1][2] + 1) / 2);
            /*
            glColor3f(1.f, 1.f, 1.f);
            if(nn.state[nn.layers-1][0] > 0)
            {
                glColor3f(0.f, 0.f, 0.f);
            }
            */
            glVertex2i(i , ii);
        }
    }

    glEnd();

    glPopMatrix();

    if(tellTime)
    {
        std::cout << "That took " << clock() - mills << " miliseconds." << std::endl;
    }

}

void Save ()
{
    std::string fileName = name;
    std::ofstream file;

    fileName.append(".txt");
    file.open(fileName.c_str(), std::ios::out);
    if (file.is_open())
    {
        file << nn.layers << std::endl;
        for(int i = 0; i < nn.layers; i++)
        {
            file << nn.layerSize[i] << std::endl;
        }
        for(int i = 0; i < nn.layers-1; i++)
        {
            for(int ii = 0; ii < nn.layerSize[i]; ii++)
            {
                for(int iii = 0; iii < nn.layerSize[i+1]; iii++)
                {
                    file << nn.connection[i][ii][iii] << std::endl;
                }
            }

        }
        file.close();
        std::cout << "I have written the data to the file." << std::endl;
    }
    else
    {
        std::cout << "I was not able to create a file." << std::endl;
    }
}

void Use ()
{
    double* input = new double[nn.layerSize[0]];
    std::ifstream file;
    std::string fileName;

    std::cout << "What is the name of your input file?" << std::endl;
    std::cin >> fileName;
    file.open(fileName.c_str(), std::ios::out);
    if (file.is_open())
    {
        for(int i = 0; i < nn.layerSize[0]; i++)
        {
            file >> input[i];
        }
        nn.Run(input);
    }
    else
    {
        std::cout << "I was unable to open that file." << std::endl;
    }
}

void Randomize()
{
    srand(time(0));
    int n;
    for(int i = 0; i < nn.layers-1; i++)
    {
        for(int ii = 0; ii < nn.layerSize[i]; ii++)
        {
            for(int iii = 0; iii < nn.layerSize[i+1]; iii++)
            {
                n = rand();
                if(n > (32767 / 2))
                {
                    n = 1;
                }
                else
                {
                    n = -1;
                }
                nn.connection[i][ii][iii] = (rand()* n) / (double)32767;
            }
        }
    }
}
